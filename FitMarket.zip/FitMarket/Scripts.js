// script.js mejorado
document.addEventListener('DOMContentLoaded', function() {
    // Animación de progreso de desafíos
    const progressBars = document.querySelectorAll('.progress');
    
    progressBars.forEach(bar => {
        const targetWidth = bar.style.width;
        bar.style.width = '0%';
        
        setTimeout(() => {
            bar.style.width = targetWidth;
        }, 500);
    });
    
    // Efecto al hacer clic en botones de desafío
    const challengeButtons = document.querySelectorAll('.btn-continue, .btn-start');
    
    challengeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const card = this.closest('.challenge-card');
            const progressBar = card.querySelector('.progress');
            const days = card.querySelectorAll('.day');
            const currentWidth = parseInt(progressBar.style.width) || 0;
            let newWidth = currentWidth;
            
            // Simular progreso
            if (this.classList.contains('btn-start')) {
                newWidth = 33;
                days[0].classList.add('completed');
                days[0].innerHTML = '<i class="fas fa-check"></i> Día 1';
            } else {
                newWidth = Math.min(currentWidth + 25, 100);
                
                // Marcar día como completado
                days.forEach((day, index) => {
                    if (day.classList.contains('active')) {
                        day.classList.remove('active');
                        day.classList.add('completed');
                        day.innerHTML = `<i class="fas fa-check"></i> Día ${index + 1}`;
                        
                        if (index < days.length - 1) {
                            days[index + 1].classList.add('active');
                        }
                    }
                });
            }
            
            // Actualizar barra de progreso
            progressBar.style.width = `${newWidth}%`;
            card.querySelector('.progress-info span:last-child').textContent = `${newWidth}%`;
            
            // Mostrar notificación
            showNotification('¡Buen trabajo! Has avanzado en tu desafío.');
            
            // Actualizar puntos si se completó
            if (newWidth === 100) {
                setTimeout(() => {
                    showNotification('¡Felicidades! Has completado el desafío y ganado tus puntos.', 'success');
                }, 1000);
            }
        });
    });
    
    // Función para mostrar notificaciones
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `notification ${type}`;
        notification.textContent = message;
        
        document.body.appendChild(notification);
        
        setTimeout(() => {
            notification.classList.add('show');
        }, 10);
        
        setTimeout(() => {
            notification.classList.remove('show');
            setTimeout(() => {
                notification.remove();
            }, 300);
        }, 3000);
    }
    
    // Efecto hover en tarjetas de recompensas
    const rewardCards = document.querySelectorAll('.reward-card');
    
    rewardCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.querySelector('.reward-image img').style.transform = 'scale(1.05)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.querySelector('.reward-image img').style.transform = 'scale(1)';
        });
    });
    
    // Botones de canjear recompensa
    const redeemButtons = document.querySelectorAll('.btn-redeem');
    
    redeemButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const rewardCard = this.closest('.reward-card');
            const rewardName = rewardCard.querySelector('h3').textContent;
            const rewardPoints = rewardCard.querySelector('.reward-points').textContent;
            
            showNotification(`¿Seguro que quieres canjear ${rewardName} por ${rewardPoints}?`, 'confirm');
        });
    });
    
    // Actualizar año en el footer
    document.querySelector('footer p').textContent = `© ${new Date().getFullYear()} FitMarket. Todos los derechos reservados.`;
    
    // Smooth scrolling para enlaces
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });
});

// Añadir estilos para notificaciones
const style = document.createElement('style');
style.textContent = `
.notification {
    position: fixed;
    bottom: 20px;
    left: 50%;
    transform: translateX(-50%);
    padding: 15px 25px;
    border-radius: 5px;
    color: white;
    font-weight: 600;
    opacity: 0;
    transition: all 0.3s ease;
    z-index: 1000;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2);
}

.notification.info {
    background-color: var(--primary-color);
}

.notification.success {
    background-color: var(--secondary-color);
}

.notification.confirm {
    background-color: var(--accent-color);
    color: var(--text-dark);
}

.notification.show {
    bottom: 30px;
    opacity: 1;
}
`;
document.head.appendChild(style);